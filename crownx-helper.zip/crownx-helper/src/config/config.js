require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID || null,
  mongoUri: process.env.MONGODB_URI,
  logChannelId: process.env.LOG_CHANNEL_ID || null,
  adminRoleIds: (process.env.ADMIN_ROLE_IDS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),

  // Legacy prefix, used alongside slash commands for quick access
  // (e.g. "$rate", "$help"). Slash commands remain the primary interface.
  prefix: '$',

  brand: {
    name: 'CrownX Exchange',
    tagline: '👑 Premium Crypto Exchange',
    footer: 'CrownX Exchange • Trusted & Secure',
    logoUrl: process.env.BRAND_LOGO_URL || null,
  },

  // Black + gold theme
  colors: {
    primary: 0x000000, // black, used for neutral/info embeds
    gold: 0xd4af37,
    success: 0x2ecc71, // Completed
    pending: 0xf1c40f, // Pending
    cancelled: 0xe74c3c, // Cancelled
    error: 0xe74c3c,
  },

  emojis: {
    crown: '👑',
    gold: '🟡',
    check: '✅',
    pending: '🕓',
    cancel: '❌',
    coin: '💱',
  },

  defaults: {
    rates: {
      C2I: 101, // 1 Crypto = ₹101
      I2C: 104, // ₹104 = 1 Crypto
    },
    limits: {
      I2C: { min: 104, max: 100000 }, // INR bounds
      C2I: { min: 1, max: 1000 }, // Crypto bounds
    },
    fees: {
      I2C: 0,
      C2I: 0,
    },
    exchangeEnabled: {
      I2C: true,
      C2I: true,
    },
  },

  cooldownSeconds: 5,
};
