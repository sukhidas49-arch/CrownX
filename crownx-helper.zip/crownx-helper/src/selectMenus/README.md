Reserved for future StringSelectMenu handlers.

The current exchange-type choice uses buttons (`src/buttons/exchangeTypeButton.js`)
plus a modal (`src/modals/amountModal.js`), matching the PrimeX/Rainy MM flow.
Drop new select-menu handler files here (exporting `{ id, execute }`) and they'll
be auto-loaded by `src/handlers/selectMenuHandler.js`.
