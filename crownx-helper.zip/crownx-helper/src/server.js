const http = require('http');

/**
 * Discord bots don't need to bind a port, but Railway (and uptime
 * pingers like UptimeRobot) are happiest when something responds on
 * PORT. This starts a minimal server only when Railway injects a
 * PORT env var — it's a no-op locally.
 */
function startKeepAliveServer(client) {
  const port = process.env.PORT;
  if (!port) return;

  const server = http.createServer((req, res) => {
    const online = client.isReady();
    res.writeHead(online ? 200 : 503, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: online ? 'online' : 'starting', bot: client.user?.tag || null }));
  });

  server.listen(port, () => {
    console.log(`🌐 Keep-alive server listening on port ${port}`);
  });
}

module.exports = { startKeepAliveServer };
