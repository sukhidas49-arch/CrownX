const { handleAmountModalSubmit } = require('../modals/amountModal');

// Maps the first segment of a modal customId to its handler function.
const modalHandlers = new Map([['amount_modal', handleAmountModalSubmit]]);

async function dispatchModal(interaction) {
  const [id] = interaction.customId.split(':');
  const handler = modalHandlers.get(id);
  if (!handler) return false;
  await handler(interaction);
  return true;
}

module.exports = { dispatchModal };
