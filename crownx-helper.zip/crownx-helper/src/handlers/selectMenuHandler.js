const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');

/**
 * Loads every select-menu handler under src/selectMenus into a
 * Collection keyed by its `id`. Currently unused by the core flows
 * (which use buttons + a modal instead) but wired up for future
 * dropdown-based features.
 */
function loadSelectMenus() {
  const menus = new Collection();
  const menusPath = path.join(__dirname, '..', 'selectMenus');
  if (!fs.existsSync(menusPath)) return menus;

  const files = fs.readdirSync(menusPath).filter((f) => f.endsWith('.js') && f !== 'README.md');
  for (const file of files) {
    const handler = require(path.join(menusPath, file));
    if (!handler?.id || !handler?.execute) continue;
    menus.set(handler.id, handler);
  }

  return menus;
}

module.exports = { loadSelectMenus };
