const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');

/**
 * Recursively loads every command file under src/commands into a
 * Collection keyed by command name.
 */
function loadCommands() {
  const commands = new Collection();
  const commandsPath = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsPath);

  for (const category of categories) {
    const categoryPath = path.join(commandsPath, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const files = fs.readdirSync(categoryPath).filter((f) => f.endsWith('.js'));
    for (const file of files) {
      const command = require(path.join(categoryPath, file));
      if (!command?.data || !command?.execute) {
        console.warn(`[commandHandler] Skipping invalid command file: ${category}/${file}`);
        continue;
      }
      commands.set(command.data.name, command);
    }
  }

  return commands;
}

module.exports = { loadCommands };
