const { AttachmentBuilder } = require('discord.js');
const { getSettings } = require('../models/Settings');
const { calculate } = require('../utils/calculator');
const { quote } = require('../utils/transactionService');
const { generateQrBuffer } = require('../utils/qr');
const { isAdmin } = require('../utils/permissions');
const {
  confirmationEmbed,
  calculatorEmbed,
  transactionDetailEmbed,
  historyCardEmbed,
} = require('../embeds/exchangeEmbeds');
const { rateEmbed, statusEmbed, limitsEmbed, feesEmbed, helpEmbed } = require('../embeds/infoEmbeds');
const { successEmbed, errorEmbed, auditLogEmbed, exchangesListEmbed } = require('../embeds/adminEmbeds');
const { panelEmbed, panelRows } = require('../embeds/panelEmbed');
const { confirmCancelRow, paginationRow } = require('../utils/components');
const { baseEmbed } = require('../embeds/baseEmbed');
const { formatINR, formatCrypto } = require('../utils/format');
const Transaction = require('../models/Transaction');
const AuditLog = require('../models/AuditLog');
const config = require('../config/config');

const PAGE_SIZE = 5;

function needAdmin(message) {
  if (!isAdmin(message.member)) {
    message.reply({ embeds: [errorEmbed('Access Denied', 'This command is for admins only.')] });
    return false;
  }
  return true;
}

/**
 * Full $-prefix command set, mirroring every slash command so the
 * bot is fully usable without opening the slash picker. Anything
 * that strictly needs a Discord modal (the free-form /exchange
 * picker) is offered here as "$exchange <type> <amount>" instead.
 */
async function handlePrefixCommand(message) {
  const withoutPrefix = message.content.slice(config.prefix.length).trim();
  const [cmd, ...args] = withoutPrefix.split(/\s+/);
  const name = cmd.toLowerCase();

  switch (name) {
    // ---------- Info ----------
    case 'help':
      return message.reply({ embeds: [helpEmbed()] });

    case 'rate': {
      const settings = await getSettings();
      return message.reply({ embeds: [rateEmbed(settings)] });
    }

    case 'status': {
      const settings = await getSettings();
      return message.reply({ embeds: [statusEmbed(settings)] });
    }

    case 'limits': {
      const settings = await getSettings();
      return message.reply({ embeds: [limitsEmbed(settings)] });
    }

    case 'fees': {
      const settings = await getSettings();
      return message.reply({ embeds: [feesEmbed(settings)] });
    }

    // ---------- Calculator / Exchange ----------
    case 'calculator': {
      const type = args[0]?.toUpperCase();
      const amount = Number(args[1]);
      if (!['I2C', 'C2I'].includes(type) || !amount || amount <= 0) {
        return message.reply(`❌ Usage: \`${config.prefix}calculator <I2C|C2I> <amount>\``);
      }
      const settings = await getSettings();
      const result = calculate(type, amount, settings.rates, settings.fees);
      return message.reply({ embeds: [calculatorEmbed(result)] });
    }

    case 'i2c':
    case 'c2i': {
      const type = name.toUpperCase();
      const amount = Number(args[0]);
      if (!amount || amount <= 0) {
        return message.reply(`❌ Usage: \`${config.prefix}${name} <amount>\``);
      }
      const { error, result } = await quote(type, amount);
      if (error) return message.reply({ embeds: [errorEmbed('Exchange Unavailable', error)] });
      return message.reply({ embeds: [confirmationEmbed(result)], components: [confirmCancelRow(type, amount)] });
    }

    case 'exchange': {
      const type = args[0]?.toUpperCase();
      const amount = Number(args[1]);
      if (!['I2C', 'C2I'].includes(type) || !amount || amount <= 0) {
        return message.reply(
          `❌ Usage: \`${config.prefix}exchange <I2C|C2I> <amount>\` (or use \`/exchange\` for the button menu)`,
        );
      }
      const { error, result } = await quote(type, amount);
      if (error) return message.reply({ embeds: [errorEmbed('Exchange Unavailable', error)] });
      return message.reply({ embeds: [confirmationEmbed(result)], components: [confirmCancelRow(type, amount)] });
    }

    // ---------- QR ----------
    case 'qr': {
      const text = args.join(' ').trim();
      if (!text) return message.reply(`❌ Usage: \`${config.prefix}qr <text or link>\``);

      let buffer;
      try {
        buffer = await generateQrBuffer(text);
      } catch (err) {
        console.error('[$qr] Failed to generate QR code:', err);
        return message.reply({
          embeds: [errorEmbed('QR Generation Failed', 'Could not generate a QR code for that input.')],
        });
      }

      const attachment = new AttachmentBuilder(buffer, { name: 'crownx-qr.png' });
      const embed = baseEmbed()
        .setTitle('📱 QR Code Generated')
        .setDescription(`\`\`\`${text.length > 200 ? `${text.slice(0, 200)}…` : text}\`\`\``)
        .setImage('attachment://crownx-qr.png');

      return message.reply({ embeds: [embed], files: [attachment] });
    }

    // ---------- Transactions ----------
    case 'history': {
      const transactions = await Transaction.find({ userId: message.author.id }).sort({ createdAt: -1 }).limit(PAGE_SIZE);
      if (!transactions.length) {
        return message.reply({
          embeds: [baseEmbed().setTitle('💱 Exchange History').setDescription('You have no exchange history yet.')],
        });
      }
      return message.reply({ embeds: transactions.map((tx) => historyCardEmbed(tx)) });
    }

    case 'my-exchanges':
    case 'myexchanges': {
      const transactions = await Transaction.find({ userId: message.author.id });
      const stats = {
        total: transactions.length,
        i2c: transactions.filter((t) => t.type === 'I2C').length,
        c2i: transactions.filter((t) => t.type === 'C2I').length,
        completed: transactions.filter((t) => t.status === 'Completed').length,
        pending: transactions.filter((t) => t.status === 'Pending').length,
        cancelled: transactions.filter((t) => t.status === 'Cancelled').length,
        inrVolume: transactions.reduce((s, t) => s + (t.type === 'I2C' ? t.inputAmount : t.outputAmount), 0),
        cryptoVolume: transactions.reduce((s, t) => s + (t.type === 'C2I' ? t.inputAmount : t.outputAmount), 0),
      };
      const embed = baseEmbed()
        .setTitle(`${config.emojis.crown} My Exchange Statistics`)
        .addFields(
          { name: 'Total Exchanges', value: `${stats.total}`, inline: true },
          { name: 'I2C Count', value: `${stats.i2c}`, inline: true },
          { name: 'C2I Count', value: `${stats.c2i}`, inline: true },
          { name: 'Completed', value: `${stats.completed}`, inline: true },
          { name: 'Pending', value: `${stats.pending}`, inline: true },
          { name: 'Cancelled', value: `${stats.cancelled}`, inline: true },
          { name: 'Total INR Volume', value: formatINR(stats.inrVolume), inline: true },
          { name: 'Total Crypto Volume', value: formatCrypto(stats.cryptoVolume), inline: true },
        );
      return message.reply({ embeds: [embed] });
    }

    case 'transaction': {
      const id = args[0]?.trim().toUpperCase();
      if (!id) return message.reply(`❌ Usage: \`${config.prefix}transaction <id>\``);
      const tx = await Transaction.findOne({ transactionId: id });
      if (!tx) return message.reply({ embeds: [errorEmbed('Not Found', `No transaction found with ID \`${id}\`.`)] });
      if (tx.userId !== message.author.id && !isAdmin(message.member)) {
        return message.reply({ embeds: [errorEmbed('Access Denied', 'You can only view your own transactions.')] });
      }
      return message.reply({ embeds: [transactionDetailEmbed(tx, { showProcessor: true })] });
    }

    // ---------- Admin ----------
    case 'panel': {
      if (!needAdmin(message)) return null;
      const settings = await getSettings();
      return message.reply({ embeds: [panelEmbed(settings)], components: panelRows() });
    }

    case 'setrate': {
      if (!needAdmin(message)) return null;
      const type = args[0]?.toUpperCase();
      const rate = Number(args[1]);
      if (!['I2C', 'C2I'].includes(type) || !rate || rate <= 0) {
        return message.reply(`❌ Usage: \`${config.prefix}setrate <I2C|C2I> <rate>\``);
      }
      const settings = await getSettings();
      const oldRate = settings.rates[type];
      settings.rates[type] = rate;
      await settings.save();
      await AuditLog.create({
        action: 'Rate Changed',
        oldValue: { type, rate: oldRate },
        newValue: { type, rate },
        adminId: message.author.id,
      });
      return message.reply({ embeds: [successEmbed('Rate Updated', `${type} rate changed from **${oldRate}** to **${rate}**.`)] });
    }

    case 'setlimit': {
      if (!needAdmin(message)) return null;
      const type = args[0]?.toUpperCase();
      const min = Number(args[1]);
      const max = Number(args[2]);
      if (!['I2C', 'C2I'].includes(type) || !Number.isFinite(min) || !Number.isFinite(max) || min >= max) {
        return message.reply(`❌ Usage: \`${config.prefix}setlimit <I2C|C2I> <min> <max>\``);
      }
      const settings = await getSettings();
      const oldLimits = { min: settings.limits[type].min, max: settings.limits[type].max };
      settings.limits[type].min = min;
      settings.limits[type].max = max;
      await settings.save();
      await AuditLog.create({
        action: 'Limit Changed',
        oldValue: { type, ...oldLimits },
        newValue: { type, min, max },
        adminId: message.author.id,
      });
      return message.reply({ embeds: [successEmbed('Limits Updated', `${type} limits set to **${min}** — **${max}**.`)] });
    }

    case 'pauseexchange': {
      if (!needAdmin(message)) return null;
      const type = args[0]?.toUpperCase();
      if (!['I2C', 'C2I', 'ALL'].includes(type)) {
        return message.reply(`❌ Usage: \`${config.prefix}pauseexchange <I2C|C2I|ALL>\``);
      }
      const settings = await getSettings();
      const types = type === 'ALL' ? ['I2C', 'C2I'] : [type];
      for (const t of types) settings.exchangeEnabled[t] = false;
      await settings.save();
      await AuditLog.create({ action: 'Exchange Paused', oldValue: null, newValue: { type }, adminId: message.author.id });
      return message.reply({ embeds: [successEmbed('Exchange Paused', `${type} exchange(s) have been disabled.`)] });
    }

    case 'resumeexchange': {
      if (!needAdmin(message)) return null;
      const type = args[0]?.toUpperCase();
      if (!['I2C', 'C2I', 'ALL'].includes(type)) {
        return message.reply(`❌ Usage: \`${config.prefix}resumeexchange <I2C|C2I|ALL>\``);
      }
      const settings = await getSettings();
      const types = type === 'ALL' ? ['I2C', 'C2I'] : [type];
      for (const t of types) settings.exchangeEnabled[t] = true;
      await settings.save();
      await AuditLog.create({ action: 'Exchange Resumed', oldValue: null, newValue: { type }, adminId: message.author.id });
      return message.reply({ embeds: [successEmbed('Exchange Resumed', `${type} exchange(s) have been re-enabled.`)] });
    }

    case 'exchanges': {
      if (!needAdmin(message)) return null;
      // Optional filters: $exchanges [I2C|C2I] [Pending|Completed|Cancelled]
      const filter = {};
      for (const a of args) {
        const up = a.toUpperCase();
        if (['I2C', 'C2I'].includes(up)) filter.type = up;
        else if (['PENDING', 'COMPLETED', 'CANCELLED'].includes(up)) filter.status = up[0] + up.slice(1).toLowerCase();
      }
      const total = await Transaction.countDocuments(filter);
      const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
      const transactions = await Transaction.find(filter).sort({ createdAt: -1 }).limit(PAGE_SIZE);
      const embed = exchangesListEmbed(transactions, 1, totalPages, filter);
      const filterKey = encodeURIComponent(JSON.stringify(filter));
      const row = paginationRow(`exchanges_page:${filterKey}`, 1, totalPages);
      return message.reply({ embeds: [embed], components: totalPages > 1 ? [row] : [] });
    }

    case 'exchange-info':
    case 'exchangeinfo': {
      if (!needAdmin(message)) return null;
      const id = args[0]?.trim().toUpperCase();
      if (!id) return message.reply(`❌ Usage: \`${config.prefix}exchange-info <id>\``);
      const tx = await Transaction.findOne({ transactionId: id });
      if (!tx) return message.reply({ embeds: [errorEmbed('Not Found', `No transaction found with ID \`${id}\`.`)] });
      return message.reply({ embeds: [transactionDetailEmbed(tx, { showProcessor: true })] });
    }

    case 'audit-log':
    case 'auditlog': {
      if (!needAdmin(message)) return null;
      const total = await AuditLog.countDocuments();
      const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
      const logs = await AuditLog.find().sort({ timestamp: -1 }).limit(PAGE_SIZE);
      const embed = auditLogEmbed(logs, 1, totalPages);
      const row = paginationRow('auditlog_page', 1, totalPages);
      return message.reply({ embeds: [embed], components: totalPages > 1 ? [row] : [] });
    }

    default:
      return null; // unknown prefix command, ignore
  }
}

module.exports = { handlePrefixCommand };
