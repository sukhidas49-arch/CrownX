const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');

/**
 * Loads every button handler under src/buttons into a Collection
 * keyed by its `id` (the first segment of the button's customId).
 */
function loadButtons() {
  const buttons = new Collection();
  const buttonsPath = path.join(__dirname, '..', 'buttons');
  const files = fs.readdirSync(buttonsPath).filter((f) => f.endsWith('.js'));

  for (const file of files) {
    const handler = require(path.join(buttonsPath, file));
    if (!handler?.id || !handler?.execute) {
      console.warn(`[buttonHandler] Skipping invalid button file: ${file}`);
      continue;
    }
    buttons.set(handler.id, handler);
  }

  return buttons;
}

module.exports = { loadButtons };
