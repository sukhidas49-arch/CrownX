const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { getSettings } = require('../../models/Settings');
const AuditLog = require('../../models/AuditLog');
const { successEmbed } = require('../../embeds/adminEmbeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pauseexchange')
    .setDescription('[Admin] Disable an exchange type')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt
        .setName('type')
        .setDescription('Exchange type (or ALL)')
        .setRequired(true)
        .addChoices({ name: 'I2C', value: 'I2C' }, { name: 'C2I', value: 'C2I' }, { name: 'ALL', value: 'ALL' }),
    ),

  async execute(interaction) {
    const type = interaction.options.getString('type');
    const settings = await getSettings();

    const types = type === 'ALL' ? ['I2C', 'C2I'] : [type];
    for (const t of types) settings.exchangeEnabled[t] = false;
    await settings.save();

    await AuditLog.create({
      action: 'Exchange Paused',
      oldValue: null,
      newValue: { type },
      adminId: interaction.user.id,
    });

    await interaction.reply({
      embeds: [successEmbed('Exchange Paused', `${type} exchange(s) have been disabled.`)],
      flags: MessageFlags.Ephemeral,
    });
  },
};
