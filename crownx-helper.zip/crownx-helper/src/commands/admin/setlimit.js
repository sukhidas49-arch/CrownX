const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { getSettings } = require('../../models/Settings');
const AuditLog = require('../../models/AuditLog');
const { successEmbed, errorEmbed } = require('../../embeds/adminEmbeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlimit')
    .setDescription('[Admin] Update exchange limits')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt
        .setName('type')
        .setDescription('Exchange type')
        .setRequired(true)
        .addChoices({ name: 'I2C', value: 'I2C' }, { name: 'C2I', value: 'C2I' }),
    )
    .addNumberOption((opt) => opt.setName('minimum').setDescription('New minimum').setRequired(true).setMinValue(0))
    .addNumberOption((opt) => opt.setName('maximum').setDescription('New maximum').setRequired(true).setMinValue(0)),

  async execute(interaction) {
    const type = interaction.options.getString('type');
    const minimum = interaction.options.getNumber('minimum');
    const maximum = interaction.options.getNumber('maximum');

    if (minimum >= maximum) {
      return interaction.reply({
        embeds: [errorEmbed('Invalid Limits', 'Minimum must be less than maximum.')],
        flags: MessageFlags.Ephemeral,
      });
    }

    const settings = await getSettings();
    const oldLimits = { ...settings.limits[type].toObject?.() ?? settings.limits[type] };
    settings.limits[type].min = minimum;
    settings.limits[type].max = maximum;
    await settings.save();

    await AuditLog.create({
      action: 'Limit Changed',
      oldValue: { type, ...oldLimits },
      newValue: { type, min: minimum, max: maximum },
      adminId: interaction.user.id,
    });

    await interaction.reply({
      embeds: [successEmbed('Limits Updated', `${type} limits set to **${minimum}** — **${maximum}**.`)],
      flags: MessageFlags.Ephemeral,
    });
  },
};
