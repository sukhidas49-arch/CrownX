const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const Transaction = require('../../models/Transaction');
const { exchangesListEmbed } = require('../../embeds/adminEmbeds');
const { paginationRow } = require('../../utils/components');

const PAGE_SIZE = 5;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('exchanges')
    .setDescription('[Admin] View all exchanges with optional filters')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption((opt) => opt.setName('user').setDescription('Filter by user'))
    .addStringOption((opt) =>
      opt.setName('type').setDescription('Filter by type').addChoices({ name: 'I2C', value: 'I2C' }, { name: 'C2I', value: 'C2I' }),
    )
    .addStringOption((opt) =>
      opt
        .setName('status')
        .setDescription('Filter by status')
        .addChoices(
          { name: 'Pending', value: 'Pending' },
          { name: 'Completed', value: 'Completed' },
          { name: 'Cancelled', value: 'Cancelled' },
        ),
    ),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const type = interaction.options.getString('type');
    const status = interaction.options.getString('status');

    const filter = {};
    if (user) filter.userId = user.id;
    if (type) filter.type = type;
    if (status) filter.status = status;

    const total = await Transaction.countDocuments(filter);
    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    const page = 1;

    const transactions = await Transaction.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * PAGE_SIZE)
      .limit(PAGE_SIZE);

    const filters = { user: user?.id, type, status };
    const embed = exchangesListEmbed(transactions, page, totalPages, filters);

    // Encode filters into the pagination customId so the button
    // handler can re-run the same query for other pages.
    const filterKey = encodeURIComponent(JSON.stringify(filters));
    const row = paginationRow(`exchanges_page:${filterKey}`, page, totalPages);

    await interaction.reply({
      embeds: [embed],
      components: totalPages > 1 ? [row] : [],
      flags: MessageFlags.Ephemeral,
    });
  },
};
