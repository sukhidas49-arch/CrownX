const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { getSettings } = require('../../models/Settings');
const { panelEmbed, panelRows } = require('../../embeds/panelEmbed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('panel')
    .setDescription('[Admin] Open the CrownX live control panel')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const settings = await getSettings();
    await interaction.reply({
      embeds: [panelEmbed(settings)],
      components: panelRows(),
      flags: MessageFlags.Ephemeral,
    });
  },
};
