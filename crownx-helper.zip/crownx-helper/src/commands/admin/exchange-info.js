const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const Transaction = require('../../models/Transaction');
const { transactionDetailEmbed } = require('../../embeds/exchangeEmbeds');
const { errorEmbed } = require('../../embeds/adminEmbeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('exchange-info')
    .setDescription('[Admin] Show full transaction details, including processor')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) => opt.setName('id').setDescription('Transaction ID').setRequired(true)),

  async execute(interaction) {
    const id = interaction.options.getString('id').trim().toUpperCase();
    const tx = await Transaction.findOne({ transactionId: id });

    if (!tx) {
      return interaction.reply({
        embeds: [errorEmbed('Not Found', `No transaction found with ID \`${id}\`.`)],
        flags: MessageFlags.Ephemeral,
      });
    }

    await interaction.reply({
      embeds: [transactionDetailEmbed(tx, { showProcessor: true })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
