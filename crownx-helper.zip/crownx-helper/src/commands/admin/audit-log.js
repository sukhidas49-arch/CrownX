const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const AuditLog = require('../../models/AuditLog');
const { auditLogEmbed } = require('../../embeds/adminEmbeds');
const { paginationRow } = require('../../utils/components');

const PAGE_SIZE = 5;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('audit-log')
    .setDescription('[Admin] View permanent audit logs')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const total = await AuditLog.countDocuments();
    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    const page = 1;

    const logs = await AuditLog.find()
      .sort({ timestamp: -1 })
      .skip((page - 1) * PAGE_SIZE)
      .limit(PAGE_SIZE);

    const embed = auditLogEmbed(logs, page, totalPages);
    const row = paginationRow('auditlog_page', page, totalPages);

    await interaction.reply({
      embeds: [embed],
      components: totalPages > 1 ? [row] : [],
      flags: MessageFlags.Ephemeral,
    });
  },
};
