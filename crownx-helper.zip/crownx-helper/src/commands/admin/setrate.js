const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { getSettings } = require('../../models/Settings');
const AuditLog = require('../../models/AuditLog');
const { successEmbed } = require('../../embeds/adminEmbeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setrate')
    .setDescription('[Admin] Update an exchange rate')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt
        .setName('type')
        .setDescription('Exchange type')
        .setRequired(true)
        .addChoices({ name: 'I2C', value: 'I2C' }, { name: 'C2I', value: 'C2I' }),
    )
    .addNumberOption((opt) => opt.setName('rate').setDescription('New rate value').setRequired(true).setMinValue(0.01)),

  async execute(interaction) {
    const type = interaction.options.getString('type');
    const rate = interaction.options.getNumber('rate');

    const settings = await getSettings();
    const oldRate = settings.rates[type];
    settings.rates[type] = rate;
    await settings.save();

    await AuditLog.create({
      action: 'Rate Changed',
      oldValue: { type, rate: oldRate },
      newValue: { type, rate },
      adminId: interaction.user.id,
    });

    await interaction.reply({
      embeds: [successEmbed('Rate Updated', `${type} rate changed from **${oldRate}** to **${rate}**.`)],
      flags: MessageFlags.Ephemeral,
    });
  },
};
