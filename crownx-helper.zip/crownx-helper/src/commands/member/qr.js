const { SlashCommandBuilder, AttachmentBuilder, MessageFlags } = require('discord.js');
const { generateQrBuffer } = require('../../utils/qr');
const { baseEmbed } = require('../../embeds/baseEmbed');
const { errorEmbed } = require('../../embeds/adminEmbeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('qr')
    .setDescription('Generate a QR code (e.g. a wallet address or payment link)')
    .addStringOption((opt) =>
      opt.setName('text').setDescription('Text, URL, or wallet address to encode').setRequired(true).setMaxLength(1000),
    )
    .addBooleanOption((opt) =>
      opt.setName('private').setDescription('Only show the QR code to you (default: true)'),
    ),

  async execute(interaction) {
    const text = interaction.options.getString('text');
    const isPrivate = interaction.options.getBoolean('private') ?? true;

    let buffer;
    try {
      buffer = await generateQrBuffer(text);
    } catch (err) {
      console.error('[qr] Failed to generate QR code:', err);
      return interaction.reply({
        embeds: [errorEmbed('QR Generation Failed', 'Could not generate a QR code for that input.')],
        flags: MessageFlags.Ephemeral,
      });
    }

    const attachment = new AttachmentBuilder(buffer, { name: 'crownx-qr.png' });
    const embed = baseEmbed()
      .setTitle('📱 QR Code Generated')
      .setDescription(`\`\`\`${text.length > 200 ? `${text.slice(0, 200)}…` : text}\`\`\``)
      .setImage('attachment://crownx-qr.png');

    await interaction.reply({
      embeds: [embed],
      files: [attachment],
      flags: isPrivate ? MessageFlags.Ephemeral : undefined,
    });
  },
};
