const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const Transaction = require('../../models/Transaction');
const { baseEmbed } = require('../../embeds/baseEmbed');
const { historyCardEmbed } = require('../../embeds/exchangeEmbeds');
const config = require('../../config/config');

const PAGE_SIZE = 5;

module.exports = {
  data: new SlashCommandBuilder().setName('history').setDescription('Show your previous exchanges'),

  async execute(interaction) {
    const transactions = await Transaction.find({ userId: interaction.user.id })
      .sort({ createdAt: -1 })
      .limit(PAGE_SIZE);

    if (!transactions.length) {
      const embed = baseEmbed()
        .setTitle(`${config.emojis.coin} Exchange History`)
        .setDescription('You have no exchange history yet.');
      return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }

    const embeds = transactions.map((tx) => historyCardEmbed(tx));
    await interaction.reply({ embeds, flags: MessageFlags.Ephemeral });
  },
};
