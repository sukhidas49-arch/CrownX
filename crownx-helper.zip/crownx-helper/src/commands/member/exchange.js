const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { baseEmbed } = require('../../embeds/baseEmbed');
const { exchangeTypeRow } = require('../../utils/components');
const config = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('exchange')
    .setDescription('Open the general exchange menu'),

  async execute(interaction) {
    const embed = baseEmbed()
      .setTitle(`${config.emojis.coin} CrownX Exchange`)
      .setDescription('**Select the type of exchange you would like to perform:**\n\n💰 **I2C** — convert INR into Crypto\n🪙 **C2I** — convert Crypto into INR');

    await interaction.reply({
      embeds: [embed],
      components: [exchangeTypeRow()],
      flags: MessageFlags.Ephemeral,
    });
  },
};
