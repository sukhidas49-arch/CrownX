const { SlashCommandBuilder } = require('discord.js');
const { helpEmbed } = require('../../embeds/infoEmbeds');

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Show the CrownX Helper command list'),

  async execute(interaction) {
    await interaction.reply({ embeds: [helpEmbed()] });
  },
};
