const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { quote } = require('../../utils/transactionService');
const { confirmationEmbed } = require('../../embeds/exchangeEmbeds');
const { confirmCancelRow } = require('../../utils/components');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('i2c')
    .setDescription('Create an INR → Crypto exchange request')
    .addNumberOption((opt) =>
      opt.setName('amount').setDescription('Amount in INR').setRequired(true).setMinValue(0.01),
    ),

  async execute(interaction) {
    const amount = interaction.options.getNumber('amount');
    const { error, result } = await quote('I2C', amount);

    if (error) {
      return interaction.reply({ content: `❌ ${error}`, flags: MessageFlags.Ephemeral });
    }

    const embed = confirmationEmbed(result);
    const row = confirmCancelRow('I2C', amount);

    await interaction.reply({ embeds: [embed], components: [row], flags: MessageFlags.Ephemeral });
  },
};
