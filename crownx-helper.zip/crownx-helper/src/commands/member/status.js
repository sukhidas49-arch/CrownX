const { SlashCommandBuilder } = require('discord.js');
const { getSettings } = require('../../models/Settings');
const { statusEmbed } = require('../../embeds/infoEmbeds');

module.exports = {
  data: new SlashCommandBuilder().setName('status').setDescription('Show exchange availability and system status'),

  async execute(interaction) {
    const settings = await getSettings();
    await interaction.reply({ embeds: [statusEmbed(settings)] });
  },
};
