const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { quote } = require('../../utils/transactionService');
const { confirmationEmbed } = require('../../embeds/exchangeEmbeds');
const { confirmCancelRow } = require('../../utils/components');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('c2i')
    .setDescription('Create a Crypto → INR exchange request')
    .addNumberOption((opt) =>
      opt.setName('amount').setDescription('Amount in Crypto').setRequired(true).setMinValue(0.01),
    ),

  async execute(interaction) {
    const amount = interaction.options.getNumber('amount');
    const { error, result } = await quote('C2I', amount);

    if (error) {
      return interaction.reply({ content: `❌ ${error}`, flags: MessageFlags.Ephemeral });
    }

    const embed = confirmationEmbed(result);
    const row = confirmCancelRow('C2I', amount);

    await interaction.reply({ embeds: [embed], components: [row], flags: MessageFlags.Ephemeral });
  },
};
