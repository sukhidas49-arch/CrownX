const { SlashCommandBuilder } = require('discord.js');
const { getSettings } = require('../../models/Settings');
const { rateEmbed } = require('../../embeds/infoEmbeds');

module.exports = {
  data: new SlashCommandBuilder().setName('rate').setDescription('Show live exchange rates'),

  async execute(interaction) {
    const settings = await getSettings();
    await interaction.reply({ embeds: [rateEmbed(settings)] });
  },
};
