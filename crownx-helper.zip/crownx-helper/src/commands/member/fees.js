const { SlashCommandBuilder } = require('discord.js');
const { getSettings } = require('../../models/Settings');
const { feesEmbed } = require('../../embeds/infoEmbeds');

module.exports = {
  data: new SlashCommandBuilder().setName('fees').setDescription('Show current exchange fees'),

  async execute(interaction) {
    const settings = await getSettings();
    await interaction.reply({ embeds: [feesEmbed(settings)] });
  },
};
