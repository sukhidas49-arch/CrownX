const { SlashCommandBuilder } = require('discord.js');
const Transaction = require('../../models/Transaction');
const { baseEmbed } = require('../../embeds/baseEmbed');
const { formatINR, formatCrypto } = require('../../utils/format');
const config = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder().setName('my-exchanges').setDescription('Show your exchange statistics'),

  async execute(interaction) {
    const transactions = await Transaction.find({ userId: interaction.user.id });

    const stats = {
      total: transactions.length,
      i2c: transactions.filter((t) => t.type === 'I2C').length,
      c2i: transactions.filter((t) => t.type === 'C2I').length,
      completed: transactions.filter((t) => t.status === 'Completed').length,
      pending: transactions.filter((t) => t.status === 'Pending').length,
      cancelled: transactions.filter((t) => t.status === 'Cancelled').length,
      inrVolume: transactions.reduce((sum, t) => sum + (t.type === 'I2C' ? t.inputAmount : t.outputAmount), 0),
      cryptoVolume: transactions.reduce((sum, t) => sum + (t.type === 'C2I' ? t.inputAmount : t.outputAmount), 0),
    };

    const embed = baseEmbed()
      .setTitle(`${config.emojis.crown} My Exchange Statistics`)
      .addFields(
        { name: 'Total Exchanges', value: `${stats.total}`, inline: true },
        { name: 'I2C Count', value: `${stats.i2c}`, inline: true },
        { name: 'C2I Count', value: `${stats.c2i}`, inline: true },
        { name: 'Completed', value: `${stats.completed}`, inline: true },
        { name: 'Pending', value: `${stats.pending}`, inline: true },
        { name: 'Cancelled', value: `${stats.cancelled}`, inline: true },
        { name: 'Total INR Volume', value: formatINR(stats.inrVolume), inline: true },
        { name: 'Total Crypto Volume', value: formatCrypto(stats.cryptoVolume), inline: true },
      );

    await interaction.reply({ embeds: [embed] });
  },
};
