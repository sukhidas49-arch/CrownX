const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const Transaction = require('../../models/Transaction');
const { transactionDetailEmbed } = require('../../embeds/exchangeEmbeds');
const { errorEmbed } = require('../../embeds/adminEmbeds');
const { isAdmin } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('transaction')
    .setDescription('Show full details for a transaction')
    .addStringOption((opt) => opt.setName('id').setDescription('Transaction ID (e.g. CX-7F3A9C21)').setRequired(true)),

  async execute(interaction) {
    const id = interaction.options.getString('id').trim().toUpperCase();
    const tx = await Transaction.findOne({ transactionId: id });

    if (!tx) {
      return interaction.reply({
        embeds: [errorEmbed('Not Found', `No transaction found with ID \`${id}\`.`)],
        flags: MessageFlags.Ephemeral,
      });
    }

    // Members may only view their own transactions; admins may view any.
    const admin = isAdmin(interaction.member);
    if (tx.userId !== interaction.user.id && !admin) {
      return interaction.reply({
        embeds: [errorEmbed('Access Denied', 'You can only view your own transactions.')],
        flags: MessageFlags.Ephemeral,
      });
    }

    await interaction.reply({
      embeds: [transactionDetailEmbed(tx, { showProcessor: true })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
