const { SlashCommandBuilder } = require('discord.js');
const { getSettings } = require('../../models/Settings');
const { limitsEmbed } = require('../../embeds/infoEmbeds');

module.exports = {
  data: new SlashCommandBuilder().setName('limits').setDescription('Show current exchange limits'),

  async execute(interaction) {
    const settings = await getSettings();
    await interaction.reply({ embeds: [limitsEmbed(settings)] });
  },
};
