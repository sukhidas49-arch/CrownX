const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { getSettings } = require('../../models/Settings');
const { calculate } = require('../../utils/calculator');
const { calculatorEmbed } = require('../../embeds/exchangeEmbeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('calculator')
    .setDescription('Calculate an exchange without creating a transaction')
    .addStringOption((opt) =>
      opt
        .setName('type')
        .setDescription('Exchange type')
        .setRequired(true)
        .addChoices({ name: 'I2C — INR → Crypto', value: 'I2C' }, { name: 'C2I — Crypto → INR', value: 'C2I' }),
    )
    .addNumberOption((opt) => opt.setName('amount').setDescription('Amount to convert').setRequired(true).setMinValue(0.01)),

  async execute(interaction) {
    const type = interaction.options.getString('type');
    const amount = interaction.options.getNumber('amount');
    const settings = await getSettings();

    const result = calculate(type, amount, settings.rates, settings.fees);
    const embed = calculatorEmbed(result);

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  },
};
