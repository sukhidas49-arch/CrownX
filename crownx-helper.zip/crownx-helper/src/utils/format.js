function formatINR(amount) {
  return `₹${Number(amount).toLocaleString('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })}`;
}

function formatCrypto(amount) {
  return `${Number(amount).toFixed(2)} C`;
}

function formatDate(date) {
  const ts = Math.floor(new Date(date).getTime() / 1000);
  return `<t:${ts}:f>`;
}

function statusEmoji(status) {
  switch (status) {
    case 'Completed':
      return '✅';
    case 'Pending':
      return '🕓';
    case 'Cancelled':
      return '❌';
    default:
      return '';
  }
}

module.exports = { formatINR, formatCrypto, formatDate, statusEmoji };
