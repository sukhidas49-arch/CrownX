const QRCode = require('qrcode');

/**
 * Generates a PNG QR code buffer for the given text, styled to match
 * the bot's gold-on-black theme.
 */
async function generateQrBuffer(text) {
  return QRCode.toBuffer(text, {
    type: 'png',
    width: 512,
    margin: 2,
    color: {
      dark: '#D4AF37', // gold
      light: '#000000', // black
    },
    errorCorrectionLevel: 'H',
  });
}

module.exports = { generateQrBuffer };
