const crypto = require('crypto');

/**
 * Generates a transaction ID like CX-7F3A9C21
 */
function generateTransactionId() {
  const random = crypto.randomBytes(4).toString('hex').toUpperCase();
  return `CX-${random}`;
}

module.exports = { generateTransactionId };
