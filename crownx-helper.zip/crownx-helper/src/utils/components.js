const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
} = require('discord.js');

/**
 * Confirm / Cancel row used by /i2c, /c2i, /exchange.
 * customId format: "confirm_exchange:<type>:<amount>" / "cancel_exchange"
 */
function confirmCancelRow(type, amount) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`confirm_exchange:${type}:${amount}`)
      .setLabel('Confirm')
      .setEmoji('✅')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('cancel_exchange')
      .setLabel('Cancel')
      .setEmoji('❌')
      .setStyle(ButtonStyle.Danger),
  );
}

/** I2C / C2I choice row used by /exchange. */
function exchangeTypeRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('exchange_type:I2C')
      .setLabel('I2C — INR → Crypto')
      .setEmoji('💰')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('exchange_type:C2I')
      .setLabel('C2I — Crypto → INR')
      .setEmoji('🪙')
      .setStyle(ButtonStyle.Secondary),
  );
}

/** Prev/Next pagination row. customId carries the context + page number. */
function paginationRow(baseId, page, totalPages) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`${baseId}:${page - 1}`)
      .setLabel('◀ Previous')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 1),
    new ButtonBuilder()
      .setCustomId(`${baseId}:${page + 1}`)
      .setLabel('Next ▶')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages),
  );
}

module.exports = { confirmCancelRow, exchangeTypeRow, paginationRow };
