const Transaction = require('../models/Transaction');
const User = require('../models/User');
const { generateTransactionId } = require('./generateId');
const { calculate } = require('./calculator');
const { getSettings } = require('../models/Settings');

/**
 * Ensures a User document exists for this Discord user.
 */
async function ensureUser(discordUser) {
  await User.findOneAndUpdate(
    { discordId: discordUser.id },
    { $setOnInsert: { discordId: discordUser.id, username: discordUser.username, joinDate: new Date() } },
    { upsert: true },
  );
}

/**
 * Validates an amount against the current limits for a type.
 * Returns null if valid, or an error message string if not.
 */
function validateLimit(type, amount, settings) {
  const { min, max } = settings.limits[type];
  if (amount < min) return `Amount is below the minimum of ${min}.`;
  if (amount > max) return `Amount exceeds the maximum of ${max}.`;
  return null;
}

/**
 * Runs the calculation for a type/amount using live settings.
 */
async function quote(type, amount) {
  const settings = await getSettings();
  if (!settings.exchangeEnabled[type]) {
    return { error: `${type} exchanges are currently disabled.` };
  }
  const limitError = validateLimit(type, amount, settings);
  if (limitError) return { error: limitError };

  const result = calculate(type, amount, settings.rates, settings.fees);
  return { result, settings };
}

/**
 * Creates a Pending transaction for a user.
 */
async function createTransaction(discordUser, type, amount) {
  const { error, result } = await quote(type, amount);
  if (error) return { error };

  await ensureUser(discordUser);

  const tx = await Transaction.create({
    transactionId: generateTransactionId(),
    userId: discordUser.id,
    username: discordUser.username,
    type: result.type,
    inputAmount: result.input,
    outputAmount: result.output,
    rate: result.rate,
    fee: result.fee,
    status: 'Pending',
  });

  return { transaction: tx };
}

module.exports = { ensureUser, validateLimit, quote, createTransaction };
