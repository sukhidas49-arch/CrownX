const config = require('../config/config');

const cooldowns = new Map(); // key: `${userId}:${commandName}` -> expiry timestamp (ms)

/**
 * Returns remaining seconds if the user is on cooldown for this
 * command, or 0 if they're free to use it (and starts a new
 * cooldown window as a side effect).
 */
function checkCooldown(userId, commandName, seconds = config.cooldownSeconds) {
  const key = `${userId}:${commandName}`;
  const now = Date.now();
  const expiry = cooldowns.get(key);

  if (expiry && expiry > now) {
    return Math.ceil((expiry - now) / 1000);
  }

  cooldowns.set(key, now + seconds * 1000);
  return 0;
}

module.exports = { checkCooldown };
