/**
 * Single source of truth for exchange math, shared by /calculator,
 * /i2c, /c2i and /exchange so results are always identical.
 *
 * I2C: Crypto = INR ÷ I2C rate   (e.g. ₹104 = 1 C)
 * C2I: INR = Crypto × C2I rate   (e.g. 1 C = ₹101)
 *
 * Crypto is always rounded to exactly 2 decimal places.
 */

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

/**
 * @param {number} inrAmount
 * @param {number} rate current I2C rate (₹ per 1 C)
 * @returns {number} crypto amount, rounded to 2dp
 */
function inrToCrypto(inrAmount, rate) {
  return round2(inrAmount / rate);
}

/**
 * @param {number} cryptoAmount
 * @param {number} rate current C2I rate (₹ per 1 C)
 * @returns {number} INR amount
 */
function cryptoToInr(cryptoAmount, rate) {
  return round2(cryptoAmount * rate);
}

/**
 * Applies a percentage fee to an output amount.
 * @param {number} amount
 * @param {number} feePercent e.g. 1.5 for 1.5%
 */
function applyFee(amount, feePercent) {
  if (!feePercent) return round2(amount);
  return round2(amount - amount * (feePercent / 100));
}

/**
 * Runs a full calculation for a given exchange type.
 * @param {'I2C'|'C2I'} type
 * @param {number} amount input amount (INR for I2C, Crypto for C2I)
 * @param {{I2C:number,C2I:number}} rates
 * @param {{I2C:number,C2I:number}} fees fee percentages
 */
function calculate(type, amount, rates, fees = { I2C: 0, C2I: 0 }) {
  if (type === 'I2C') {
    const rate = rates.I2C;
    const rawOutput = inrToCrypto(amount, rate);
    const output = applyFee(rawOutput, fees.I2C);
    return { type, input: amount, output, rate, fee: fees.I2C || 0 };
  }

  if (type === 'C2I') {
    const rate = rates.C2I;
    const rawOutput = cryptoToInr(amount, rate);
    const output = applyFee(rawOutput, fees.C2I);
    return { type, input: round2(amount), output, rate, fee: fees.C2I || 0 };
  }

  throw new Error(`Unknown exchange type: ${type}`);
}

module.exports = { round2, inrToCrypto, cryptoToInr, applyFee, calculate };
