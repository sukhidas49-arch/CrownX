const { PermissionFlagsBits } = require('discord.js');
const config = require('../config/config');

/**
 * Returns true if the given guild member counts as a CrownX admin:
 * either they hold Discord's Administrator permission, or their
 * roles intersect with the configured ADMIN_ROLE_IDS.
 */
function isAdmin(member) {
  if (!member) return false;
  if (member.permissions?.has(PermissionFlagsBits.Administrator)) return true;
  if (!config.adminRoleIds.length) return false;
  return member.roles?.cache?.some((role) => config.adminRoleIds.includes(role.id));
}

module.exports = { isAdmin };
