const { Schema, model } = require('mongoose');

const transactionSchema = new Schema({
  transactionId: { type: String, required: true, unique: true, index: true },
  userId: { type: String, required: true, index: true },
  username: { type: String, required: true },
  type: { type: String, enum: ['I2C', 'C2I'], required: true },
  inputAmount: { type: Number, required: true },
  outputAmount: { type: Number, required: true },
  rate: { type: Number, required: true },
  fee: { type: Number, default: 0 },
  status: {
    type: String,
    enum: ['Pending', 'Completed', 'Cancelled'],
    default: 'Pending',
  },
  processedBy: { type: String, default: null },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

transactionSchema.pre('save', function (next) {
  this.updatedAt = new Date();
  next();
});

module.exports = model('Transaction', transactionSchema);
