const { Schema, model } = require('mongoose');
const config = require('../config/config');

const settingsSchema = new Schema({
  key: { type: String, default: 'global', unique: true },
  rates: {
    C2I: { type: Number, default: config.defaults.rates.C2I },
    I2C: { type: Number, default: config.defaults.rates.I2C },
  },
  limits: {
    I2C: {
      min: { type: Number, default: config.defaults.limits.I2C.min },
      max: { type: Number, default: config.defaults.limits.I2C.max },
    },
    C2I: {
      min: { type: Number, default: config.defaults.limits.C2I.min },
      max: { type: Number, default: config.defaults.limits.C2I.max },
    },
  },
  fees: {
    I2C: { type: Number, default: config.defaults.fees.I2C },
    C2I: { type: Number, default: config.defaults.fees.C2I },
  },
  exchangeEnabled: {
    I2C: { type: Boolean, default: config.defaults.exchangeEnabled.I2C },
    C2I: { type: Boolean, default: config.defaults.exchangeEnabled.C2I },
  },
});

const Settings = model('Settings', settingsSchema);

/**
 * Fetch the single global settings document, creating it with
 * defaults on first run.
 */
async function getSettings() {
  let settings = await Settings.findOne({ key: 'global' });
  if (!settings) {
    settings = await Settings.create({ key: 'global' });
  }
  return settings;
}

module.exports = { Settings, getSettings };
