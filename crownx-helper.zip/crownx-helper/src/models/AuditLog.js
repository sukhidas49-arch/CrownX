const { Schema, model } = require('mongoose');

const auditLogSchema = new Schema({
  action: { type: String, required: true },
  oldValue: { type: Schema.Types.Mixed, default: null },
  newValue: { type: Schema.Types.Mixed, default: null },
  adminId: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
});

module.exports = model('AuditLog', auditLogSchema);
