const { Schema, model } = require('mongoose');

const userSchema = new Schema({
  discordId: { type: String, required: true, unique: true, index: true },
  username: { type: String, required: true },
  joinDate: { type: Date, default: Date.now },
});

module.exports = model('User', userSchema);
