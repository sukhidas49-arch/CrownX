const { baseEmbed } = require('../embeds/baseEmbed');
const config = require('../config/config');

/** customId: "cancel_exchange" */
module.exports = {
  id: 'cancel_exchange',
  async execute(interaction) {
    const embed = baseEmbed({ color: config.colors.cancelled })
      .setTitle('❌ Exchange Cancelled')
      .setDescription('No transaction was created.');

    await interaction.update({ embeds: [embed], components: [] });
  },
};
