const AuditLog = require('../models/AuditLog');
const { auditLogEmbed } = require('../embeds/adminEmbeds');
const { paginationRow } = require('../utils/components');

const PAGE_SIZE = 5;

/** customId: "auditlog_page:<page>" */
module.exports = {
  id: 'auditlog_page',
  async execute(interaction, args) {
    const page = Number(args[0]);

    const total = await AuditLog.countDocuments();
    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

    const logs = await AuditLog.find()
      .sort({ timestamp: -1 })
      .skip((page - 1) * PAGE_SIZE)
      .limit(PAGE_SIZE);

    const embed = auditLogEmbed(logs, page, totalPages);
    const row = paginationRow('auditlog_page', page, totalPages);

    await interaction.update({ embeds: [embed], components: [row] });
  },
};
