const { buildAmountModal } = require('../modals/amountModal');

/** customId: "exchange_type:<I2C|C2I>" */
module.exports = {
  id: 'exchange_type',
  async execute(interaction, args) {
    const [type] = args;
    await interaction.showModal(buildAmountModal(type));
  },
};
