const { MessageFlags } = require('discord.js');
const { getSettings } = require('../models/Settings');
const AuditLog = require('../models/AuditLog');
const { isAdmin } = require('../utils/permissions');
const { panelEmbed, panelRows } = require('../embeds/panelEmbed');
const { auditLogEmbed } = require('../embeds/adminEmbeds');
const { paginationRow } = require('../utils/components');

const PAGE_SIZE = 5;

/** customId: "panel_action:<pause|resume|pauseall|resumeall|auditlog|refresh>:<I2C|C2I|ALL>" */
module.exports = {
  id: 'panel_action',
  async execute(interaction, args) {
    if (!isAdmin(interaction.member)) {
      return interaction.reply({ content: '❌ Admins only.', flags: MessageFlags.Ephemeral });
    }

    const [action, type] = args;

    if (action === 'auditlog') {
      const total = await AuditLog.countDocuments();
      const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
      const logs = await AuditLog.find().sort({ timestamp: -1 }).limit(PAGE_SIZE);

      return interaction.reply({
        embeds: [auditLogEmbed(logs, 1, totalPages)],
        components: totalPages > 1 ? [paginationRow('auditlog_page', 1, totalPages)] : [],
        flags: MessageFlags.Ephemeral,
      });
    }

    const settings = await getSettings();

    if (action === 'pause' || action === 'resume') {
      settings.exchangeEnabled[type] = action === 'resume';
      await settings.save();
      await AuditLog.create({
        action: action === 'pause' ? 'Exchange Paused' : 'Exchange Resumed',
        oldValue: null,
        newValue: { type },
        adminId: interaction.user.id,
      });
    } else if (action === 'pauseall' || action === 'resumeall') {
      const enabled = action === 'resumeall';
      settings.exchangeEnabled.I2C = enabled;
      settings.exchangeEnabled.C2I = enabled;
      await settings.save();
      await AuditLog.create({
        action: enabled ? 'Exchange Resumed' : 'Exchange Paused',
        oldValue: null,
        newValue: { type: 'ALL' },
        adminId: interaction.user.id,
      });
    }
    // "refresh" falls through and just re-renders below with current settings

    const freshSettings = await getSettings();
    await interaction.update({ embeds: [panelEmbed(freshSettings)], components: panelRows() });
  },
};
