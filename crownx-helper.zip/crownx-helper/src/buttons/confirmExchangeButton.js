const { MessageFlags } = require('discord.js');
const { createTransaction } = require('../utils/transactionService');
const { transactionCreatedEmbed } = require('../embeds/exchangeEmbeds');
const { errorEmbed } = require('../embeds/adminEmbeds');

/** customId: "confirm_exchange:<type>:<amount>" */
module.exports = {
  id: 'confirm_exchange',
  async execute(interaction, args) {
    const [type, amountRaw] = args;
    const amount = Number(amountRaw);

    const { error, transaction } = await createTransaction(interaction.user, type, amount);

    if (error) {
      return interaction.update({ embeds: [errorEmbed('Exchange Failed', error)], components: [] });
    }

    await interaction.update({ embeds: [transactionCreatedEmbed(transaction)], components: [] });
  },
};
