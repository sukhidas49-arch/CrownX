const Transaction = require('../models/Transaction');
const { exchangesListEmbed } = require('../embeds/adminEmbeds');
const { paginationRow } = require('../utils/components');

const PAGE_SIZE = 5;

/** customId: "exchanges_page:<encodedFilters>:<page>" */
module.exports = {
  id: 'exchanges_page',
  async execute(interaction, args) {
    const [filterKey, pageRaw] = args;
    const page = Number(pageRaw);
    const filters = JSON.parse(decodeURIComponent(filterKey));

    const filter = {};
    if (filters.user) filter.userId = filters.user;
    if (filters.type) filter.type = filters.type;
    if (filters.status) filter.status = filters.status;

    const total = await Transaction.countDocuments(filter);
    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

    const transactions = await Transaction.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * PAGE_SIZE)
      .limit(PAGE_SIZE);

    const embed = exchangesListEmbed(transactions, page, totalPages, filters);
    const row = paginationRow(`exchanges_page:${filterKey}`, page, totalPages);

    await interaction.update({ embeds: [embed], components: [row] });
  },
};
