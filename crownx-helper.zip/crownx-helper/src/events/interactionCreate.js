const { MessageFlags } = require('discord.js');
const { checkCooldown } = require('../utils/cooldown');
const { dispatchModal } = require('../handlers/modalHandler');
const { errorEmbed } = require('../embeds/adminEmbeds');

module.exports = {
  name: 'interactionCreate',
  once: false,
  async execute(interaction, client) {
    try {
      // Slash commands
      if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        const remaining = checkCooldown(interaction.user.id, interaction.commandName);
        if (remaining > 0) {
          return interaction.reply({
            content: `⏳ Please wait ${remaining}s before using \`/${interaction.commandName}\` again.`,
            flags: MessageFlags.Ephemeral,
          });
        }

        await command.execute(interaction, client);
        return;
      }

      // Buttons (customId format: "handlerId:arg1:arg2:...")
      if (interaction.isButton()) {
        const [id, ...args] = interaction.customId.split(':');
        const handler = client.buttons.get(id);
        if (!handler) return;
        await handler.execute(interaction, args, client);
        return;
      }

      // Modals
      if (interaction.isModalSubmit()) {
        const handled = await dispatchModal(interaction);
        if (!handled) {
          await interaction.reply({ content: '❌ Unknown form submission.', flags: MessageFlags.Ephemeral });
        }
        return;
      }

      // Select menus (reserved for future dropdown features)
      if (interaction.isStringSelectMenu()) {
        const [id, ...args] = interaction.customId.split(':');
        const handler = client.selectMenus.get(id);
        if (!handler) return;
        await handler.execute(interaction, args, client);
        return;
      }
    } catch (err) {
      console.error('[interactionCreate] Error handling interaction:', err);

      const payload = {
        embeds: [errorEmbed('Something Went Wrong', 'An unexpected error occurred while processing this action.')],
        flags: MessageFlags.Ephemeral,
      };

      try {
        if (interaction.deferred || interaction.replied) {
          await interaction.followUp(payload);
        } else if (interaction.isRepliable?.()) {
          await interaction.reply(payload);
        }
      } catch (followUpErr) {
        console.error('[interactionCreate] Failed to report error to user:', followUpErr);
      }
    }
  },
};
