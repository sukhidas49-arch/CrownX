const { handlePrefixCommand } = require('../handlers/prefixHandler');
const config = require('../config/config');

module.exports = {
  name: 'messageCreate',
  once: false,
  async execute(message) {
    if (message.author.bot) return;
    if (!message.content.startsWith(config.prefix)) return;

    try {
      await handlePrefixCommand(message);
    } catch (err) {
      console.error('[messageCreate] Error handling prefix command:', err);
      await message.reply('❌ Something went wrong running that command.').catch(() => {});
    }
  },
};
