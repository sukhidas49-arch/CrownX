const { ActivityType } = require('discord.js');
const config = require('../config/config');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`👑 CrownX Helper online as ${client.user.tag}`);
    client.user.setPresence({
      activities: [{ name: `${config.prefix}help • Crypto ⇄ INR`, type: ActivityType.Watching }],
      status: 'online',
    });
  },
};
