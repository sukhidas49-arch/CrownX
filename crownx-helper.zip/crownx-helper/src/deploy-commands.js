const { REST, Routes } = require('discord.js');
const config = require('./config/config');
const { loadCommands } = require('./handlers/commandHandler');

async function deploy() {
  if (!config.token || !config.clientId) {
    console.error('❌ Missing DISCORD_TOKEN or CLIENT_ID in your .env file.');
    process.exit(1);
  }

  const commands = loadCommands();
  const body = commands.map((c) => c.data.toJSON());

  const rest = new REST().setToken(config.token);

  try {
    const route = config.guildId
      ? Routes.applicationGuildCommands(config.clientId, config.guildId)
      : Routes.applicationCommands(config.clientId);

    console.log(`🚀 Deploying ${body.length} slash commands${config.guildId ? ' (guild)' : ' (global)'}...`);
    await rest.put(route, { body });
    console.log('✅ Slash commands deployed successfully.');
  } catch (err) {
    console.error('❌ Failed to deploy slash commands:', err);
    process.exit(1);
  }
}

deploy();
