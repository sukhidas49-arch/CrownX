const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, MessageFlags } = require('discord.js');
const { quote } = require('../utils/transactionService');
const { confirmationEmbed } = require('../embeds/exchangeEmbeds');
const { confirmCancelRow } = require('../utils/components');

/** customId format: "amount_modal:<type>" */
function buildAmountModal(type) {
  const modal = new ModalBuilder().setCustomId(`amount_modal:${type}`).setTitle(`${type} Exchange — Enter Amount`);

  const input = new TextInputBuilder()
    .setCustomId('amount')
    .setLabel(type === 'I2C' ? 'INR amount to convert' : 'Crypto amount to convert')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder(type === 'I2C' ? 'e.g. 520' : 'e.g. 5')
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

async function handleAmountModalSubmit(interaction) {
  const [, type] = interaction.customId.split(':');
  const raw = interaction.fields.getTextInputValue('amount');
  const amount = Number(raw);

  if (Number.isNaN(amount) || amount <= 0) {
    return interaction.reply({ content: '❌ Please enter a valid positive number.', flags: MessageFlags.Ephemeral });
  }

  const { error, result } = await quote(type, amount);
  if (error) {
    return interaction.reply({ content: `❌ ${error}`, flags: MessageFlags.Ephemeral });
  }

  const embed = confirmationEmbed(result);
  const row = confirmCancelRow(type, amount);

  await interaction.reply({ embeds: [embed], components: [row], flags: MessageFlags.Ephemeral });
}

module.exports = { buildAmountModal, handleAmountModalSubmit };
