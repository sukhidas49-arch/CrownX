const { Client, GatewayIntentBits, Partials } = require('discord.js');
const mongoose = require('mongoose');
const config = require('./config/config');
const { loadCommands } = require('./handlers/commandHandler');
const { loadButtons } = require('./handlers/buttonHandler');
const { loadSelectMenus } = require('./handlers/selectMenuHandler');
const { loadEvents } = require('./handlers/eventHandler');
const { startKeepAliveServer } = require('./server');

if (!config.token) {
  console.error('❌ Missing DISCORD_TOKEN in your .env file.');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // required for the $ prefix commands
  ],
  partials: [Partials.Channel],
});

client.commands = loadCommands();
client.buttons = loadButtons();
client.selectMenus = loadSelectMenus();

loadEvents(client);

async function main() {
  try {
    await mongoose.connect(config.mongoUri);
    console.log('🗄️  Connected to MongoDB');
  } catch (err) {
    console.error('❌ Failed to connect to MongoDB:', err.message);
    process.exit(1);
  }

  await client.login(config.token);
  startKeepAliveServer(client);
}

main();

process.on('unhandledRejection', (err) => {
  console.error('Unhandled promise rejection:', err);
});
