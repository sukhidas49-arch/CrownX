const { baseEmbed, statusColor } = require('./baseEmbed');
const { formatINR, formatCrypto, formatDate, statusEmoji } = require('../utils/format');
const config = require('../config/config');

function typeLabel(type) {
  return type === 'I2C' ? 'INR → Crypto' : 'Crypto → INR';
}

function formatAmount(type, side, amount) {
  // side: 'input' | 'output'
  const isInrSide = (type === 'I2C' && side === 'input') || (type === 'C2I' && side === 'output');
  return isInrSide ? formatINR(amount) : formatCrypto(amount);
}

/** Confirmation embed shown before a transaction is created. */
function confirmationEmbed({ type, input, output, rate, fee }) {
  return baseEmbed()
    .setTitle(`${config.emojis.coin} Confirm Exchange — ${typeLabel(type)}`)
    .setDescription('Review the details below, then confirm to create your exchange request.')
    .addFields(
      { name: 'You Send', value: formatAmount(type, 'input', input), inline: true },
      { name: 'You Receive', value: formatAmount(type, 'output', output), inline: true },
      { name: '\u200b', value: '\u200b', inline: true },
      { name: 'Rate', value: type === 'I2C' ? `₹${rate} = 1 C` : `1 C = ₹${rate}`, inline: true },
      { name: 'Fee', value: fee ? `${fee}%` : '0%', inline: true },
    );
}

/** Embed shown after a transaction is created (Pending). */
function transactionCreatedEmbed(tx) {
  return baseEmbed({ color: statusColor(tx.status) })
    .setTitle(`${config.emojis.check} Exchange Request Created`)
    .addFields(
      { name: 'Transaction ID', value: `\`${tx.transactionId}\``, inline: true },
      { name: 'Type', value: typeLabel(tx.type), inline: true },
      { name: 'Status', value: `${statusEmoji(tx.status)} ${tx.status}`, inline: true },
      { name: 'Input', value: formatAmount(tx.type, 'input', tx.inputAmount), inline: true },
      { name: 'Output', value: formatAmount(tx.type, 'output', tx.outputAmount), inline: true },
      { name: 'Rate', value: `${tx.rate}`, inline: true },
      { name: 'Fee', value: tx.fee ? `${tx.fee}%` : '0%', inline: true },
    );
}

/** Full transaction detail embed, used by /transaction and /exchange-info. */
function transactionDetailEmbed(tx, { showProcessor = false } = {}) {
  const embed = baseEmbed({ color: statusColor(tx.status) })
    .setTitle(`${config.emojis.coin} Transaction Details`)
    .addFields(
      { name: 'Transaction ID', value: `\`${tx.transactionId}\``, inline: true },
      { name: 'User', value: `<@${tx.userId}>`, inline: true },
      { name: 'Type', value: typeLabel(tx.type), inline: true },
      { name: 'Input', value: formatAmount(tx.type, 'input', tx.inputAmount), inline: true },
      { name: 'Output', value: formatAmount(tx.type, 'output', tx.outputAmount), inline: true },
      { name: 'Rate', value: `${tx.rate}`, inline: true },
      { name: 'Fee', value: tx.fee ? `${tx.fee}%` : '0%', inline: true },
      { name: 'Status', value: `${statusEmoji(tx.status)} ${tx.status}`, inline: true },
      { name: 'Date', value: formatDate(tx.createdAt), inline: true },
    );

  if (showProcessor) {
    embed.addFields({
      name: 'Staff Processor',
      value: tx.processedBy ? `<@${tx.processedBy}>` : 'Not yet processed',
      inline: false,
    });
  }

  return embed;
}

/** Calculator-only result embed — no transaction is created. */
function calculatorEmbed({ type, input, output, rate }) {
  return baseEmbed()
    .setTitle(`🧮 Calculator — ${typeLabel(type)}`)
    .addFields(
      { name: 'Amount Given', value: formatAmount(type, 'input', input), inline: true },
      { name: 'Rate', value: type === 'I2C' ? `₹${rate} = 1 C` : `1 C = ₹${rate}`, inline: true },
      { name: 'Amount Received', value: formatAmount(type, 'output', output), inline: true },
    )
    .setDescription('⚠️ This is a calculation only — no exchange has been created.');
}

/** Single history card for one transaction. */
function historyCardEmbed(tx) {
  return baseEmbed({ color: statusColor(tx.status) }).addFields({
    name: `${tx.transactionId} • ${typeLabel(tx.type)}`,
    value:
      `**Input:** ${formatAmount(tx.type, 'input', tx.inputAmount)}\n` +
      `**Output:** ${formatAmount(tx.type, 'output', tx.outputAmount)}\n` +
      `**Status:** ${statusEmoji(tx.status)} ${tx.status}\n` +
      `**Date:** ${formatDate(tx.createdAt)}`,
  });
}

module.exports = {
  typeLabel,
  formatAmount,
  confirmationEmbed,
  transactionCreatedEmbed,
  transactionDetailEmbed,
  calculatorEmbed,
  historyCardEmbed,
};
