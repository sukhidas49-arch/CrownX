const { baseEmbed, statusColor } = require('./baseEmbed');
const { formatDate, statusEmoji } = require('../utils/format');
const { typeLabel, formatAmount } = require('./exchangeEmbeds');
const config = require('../config/config');

function successEmbed(title, description) {
  return baseEmbed({ color: config.colors.success }).setTitle(`✅ ${title}`).setDescription(description);
}

function errorEmbed(title, description) {
  return baseEmbed({ color: config.colors.error }).setTitle(`❌ ${title}`).setDescription(description);
}

function auditLogEmbed(logs, page, totalPages) {
  const embed = baseEmbed().setTitle('📋 Audit Log').setFooter({
    text: `${config.brand.footer} • Page ${page}/${totalPages}`,
  });

  if (!logs.length) {
    embed.setDescription('No audit log entries found.');
    return embed;
  }

  for (const log of logs) {
    embed.addFields({
      name: `${log.action} • ${formatDate(log.timestamp)}`,
      value:
        `**Admin:** <@${log.adminId}>\n` +
        `**Old:** \`${JSON.stringify(log.oldValue)}\`\n` +
        `**New:** \`${JSON.stringify(log.newValue)}\``,
    });
  }

  return embed;
}

function exchangesListEmbed(transactions, page, totalPages, filters = {}) {
  const filterParts = [];
  if (filters.user) filterParts.push(`User: <@${filters.user}>`);
  if (filters.type) filterParts.push(`Type: ${filters.type}`);
  if (filters.status) filterParts.push(`Status: ${filters.status}`);

  const embed = baseEmbed()
    .setTitle('📂 All Exchanges')
    .setFooter({ text: `${config.brand.footer} • Page ${page}/${totalPages}` });

  if (filterParts.length) embed.setDescription(`Filters: ${filterParts.join(' | ')}`);

  if (!transactions.length) {
    embed.addFields({ name: 'No results', value: 'No exchanges match these filters.' });
    return embed;
  }

  for (const tx of transactions) {
    embed.addFields({
      name: `${tx.transactionId} • ${typeLabel(tx.type)} • ${statusEmoji(tx.status)} ${tx.status}`,
      value:
        `User: <@${tx.userId}>\n` +
        `In: ${formatAmount(tx.type, 'input', tx.inputAmount)} → Out: ${formatAmount(tx.type, 'output', tx.outputAmount)}\n` +
        `Date: ${formatDate(tx.createdAt)}`,
    });
  }

  return embed;
}

module.exports = { successEmbed, errorEmbed, auditLogEmbed, exchangesListEmbed };
