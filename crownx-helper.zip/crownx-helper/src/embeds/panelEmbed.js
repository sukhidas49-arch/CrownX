const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed, DIVIDER } = require('./baseEmbed');
const config = require('../config/config');

/**
 * Builds the live admin control panel: current status + rates at a
 * glance, plus one-click buttons for the most common admin actions.
 * Reused by /panel, $panel, and the panel's own buttons after an
 * action is taken (so the panel refreshes in place).
 */
function panelEmbed(settings) {
  const line = (enabled) => (enabled ? '🟢 Live' : '🔴 Paused');

  return baseEmbed()
    .setTitle(`${config.emojis.crown} CrownX Admin Panel`)
    .setDescription(`${DIVIDER}\n**Control the exchange in real time.**\n${DIVIDER}`)
    .addFields(
      { name: 'I2C', value: `${line(settings.exchangeEnabled.I2C)}\n₹${settings.rates.I2C} = 1 C`, inline: true },
      { name: 'C2I', value: `${line(settings.exchangeEnabled.C2I)}\n1 C = ₹${settings.rates.C2I}`, inline: true },
      { name: '\u200b', value: '\u200b', inline: true },
      {
        name: 'Fees',
        value: `I2C: ${settings.fees.I2C}% • C2I: ${settings.fees.C2I}%`,
        inline: false,
      },
    );
}

function panelRows() {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('panel_action:pause:I2C').setLabel('Pause I2C').setEmoji('⏸️').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('panel_action:resume:I2C').setLabel('Resume I2C').setEmoji('▶️').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('panel_action:pause:C2I').setLabel('Pause C2I').setEmoji('⏸️').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('panel_action:resume:C2I').setLabel('Resume C2I').setEmoji('▶️').setStyle(ButtonStyle.Success),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('panel_action:pauseall:ALL').setLabel('Pause All').setEmoji('🛑').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('panel_action:resumeall:ALL').setLabel('Resume All').setEmoji('✅').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('panel_action:auditlog:ALL').setLabel('Audit Log').setEmoji('📋').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('panel_action:refresh:ALL').setLabel('Refresh').setEmoji('🔄').setStyle(ButtonStyle.Secondary),
  );

  return [row1, row2];
}

module.exports = { panelEmbed, panelRows };
