const { baseEmbed, DIVIDER } = require('./baseEmbed');
const { formatINR, formatCrypto } = require('../utils/format');
const config = require('../config/config');

function rateEmbed(settings) {
  return baseEmbed()
    .setTitle('💹 Live Exchange Rates')
    .addFields(
      { name: 'C2I (Crypto → INR)', value: `1 C = ₹${settings.rates.C2I}`, inline: true },
      { name: 'I2C (INR → Crypto)', value: `₹${settings.rates.I2C} = 1 C`, inline: true },
      { name: '\u200b', value: '\u200b', inline: true },
      { name: 'Supported Exchanges', value: '• C2I — Crypto → INR\n• I2C — INR → Crypto' },
    );
}

function statusEmbed(settings) {
  const line = (enabled) => (enabled ? '🟢 Available' : '🔴 Disabled');
  return baseEmbed()
    .setTitle('📡 System Status')
    .addFields(
      { name: 'I2C', value: line(settings.exchangeEnabled.I2C), inline: true },
      { name: 'C2I', value: line(settings.exchangeEnabled.C2I), inline: true },
      { name: '\u200b', value: '\u200b', inline: true },
      { name: 'Current Rates', value: `I2C: ₹${settings.rates.I2C} = 1 C\nC2I: 1 C = ₹${settings.rates.C2I}` },
      {
        name: 'System',
        value:
          settings.exchangeEnabled.I2C || settings.exchangeEnabled.C2I
            ? '🟢 Operational'
            : '🔴 Under Maintenance',
      },
    );
}

function limitsEmbed(settings) {
  return baseEmbed()
    .setTitle('📏 Exchange Limits')
    .addFields(
      {
        name: 'I2C (INR → Crypto)',
        value: `Minimum: ${formatINR(settings.limits.I2C.min)}\nMaximum: ${formatINR(settings.limits.I2C.max)}`,
        inline: true,
      },
      {
        name: 'C2I (Crypto → INR)',
        value: `Minimum: ${formatCrypto(settings.limits.C2I.min)}\nMaximum: ${formatCrypto(settings.limits.C2I.max)}`,
        inline: true,
      },
    );
}

function feesEmbed(settings) {
  return baseEmbed()
    .setTitle('💸 Exchange Fees')
    .addFields(
      { name: 'I2C Fee', value: `${settings.fees.I2C}%`, inline: true },
      { name: 'C2I Fee', value: `${settings.fees.C2I}%`, inline: true },
    );
}

function maintenanceEmbed(type) {
  return baseEmbed({ color: config.colors.cancelled })
    .setTitle('🛠️ Under Maintenance')
    .setDescription(`${type} exchanges are currently paused. Please try again later.`);
}

function helpEmbed() {
  return baseEmbed()
    .setTitle(`${config.emojis.crown} CrownX Helper`)
    .setDescription(
      `${DIVIDER}\n**Your trusted gateway between INR and Crypto.**\nUse the commands below to exchange, calculate, and track your transactions.\n${DIVIDER}`,
    )
    .addFields(
      { name: '💱 Exchange', value: '`/i2c` `/c2i` `/exchange`', inline: false },
      { name: '🧮 Calculator', value: '`/calculator` `/rate`', inline: false },
      { name: '📱 QR Code', value: '`/qr` — generate a QR for any text, link, or wallet address', inline: false },
      { name: '📜 Transactions', value: '`/history` `/transaction` `/my-exchanges`', inline: false },
      { name: 'ℹ️ Information', value: '`/status` `/limits` `/fees` `/help`', inline: false },
      { name: '⌨️ Quick Prefix', value: `Every command above also works with \`${config.prefix}\`, e.g. \`${config.prefix}rate\` or \`${config.prefix}qr <text>\`.` },
    );
}

module.exports = { rateEmbed, statusEmbed, limitsEmbed, feesEmbed, maintenanceEmbed, helpEmbed };
