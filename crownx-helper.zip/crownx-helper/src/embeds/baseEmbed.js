const { EmbedBuilder } = require('discord.js');
const config = require('../config/config');

/**
 * Returns a pre-styled EmbedBuilder: black/gold theme, branded
 * author eyebrow, brand footer, timestamp. Pass a color override
 * (defaults to gold). Set `author: false` to omit the eyebrow line
 * (used sparingly, e.g. on stacked history cards).
 */
function baseEmbed({ color = config.colors.gold, timestamp = true, author = true } = {}) {
  const embed = new EmbedBuilder().setColor(color).setFooter({
    text: config.brand.footer,
    iconURL: config.brand.logoUrl || undefined,
  });

  if (author) {
    embed.setAuthor({
      name: config.brand.tagline,
      iconURL: config.brand.logoUrl || undefined,
    });
  }

  if (config.brand.logoUrl) embed.setThumbnail(config.brand.logoUrl);
  if (timestamp) embed.setTimestamp();

  return embed;
}

/** A thin gold divider for use inside embed descriptions. */
const DIVIDER = '━━━━━━━━━━━━━━━━━━━━';

function statusColor(status) {
  switch (status) {
    case 'Completed':
      return config.colors.success;
    case 'Pending':
      return config.colors.pending;
    case 'Cancelled':
      return config.colors.cancelled;
    default:
      return config.colors.gold;
  }
}

module.exports = { baseEmbed, statusColor, DIVIDER };
