# 👑 CrownX Helper

A premium black/gold Discord exchange bot for **I2C** (INR → Crypto) and **C2I** (Crypto → INR), modeled on the PrimeX / Rainy MM Exchange Helper workflow. Slash commands are the primary interface; quick `$`-prefix text commands are also included for common lookups.

## Features

- Full exchange flow: `/i2c`, `/c2i`, `/exchange` (button + modal picker)
- Calculator-only mode: `/calculator` (always matches real exchange math)
- **QR code generator**: `/qr <text>` — encode a wallet address, payment link, or any text as a gold/black QR image
- **Live admin control panel**: `/panel` (or `$panel`) — one-click Pause/Resume I2C, C2I, or All, plus a Refresh and an Audit Log shortcut, all in a single embed with buttons
- Info commands: `/rate`, `/status`, `/limits`, `/fees`, `/help`
- Transaction tracking: `/history`, `/my-exchanges`, `/transaction`
- Admin panel commands: `/setrate`, `/setlimit`, `/pauseexchange`, `/resumeexchange`, `/exchanges` (filtered + paginated), `/exchange-info`, `/audit-log`
- **`$` prefix covers every command above** — `$i2c`, `$c2i`, `$exchange`, `$calculator`, `$qr`, `$panel`, `$rate`, `$status`, `$limits`, `$fees`, `$help`, `$history`, `$my-exchanges`, `$transaction`, and every admin command (`$setrate`, `$setlimit`, `$pauseexchange`, `$resumeexchange`, `$exchanges`, `$exchange-info`, `$audit-log`)
- MongoDB persistence (users, transactions, settings, audit logs)
- Cooldowns, permission checks, centralized error handling

## Deploying to Railway (24/7 hosting)

1. **Push this project to a GitHub repo** (Railway deploys from GitHub, or you can use the Railway CLI to deploy straight from this folder).

2. **Create a new Railway project** → *Deploy from GitHub repo* → select the repo.
   - Railway auto-detects Node via Nixpacks and will run `npm install` then `npm start` (also pinned in `railway.json` / `Procfile`).

3. **Add MongoDB.** Easiest option: in the same Railway project click *New* → *Database* → *Add MongoDB*. Railway gives you a `MONGO_URL` — copy it.

4. **Set environment variables** on the service (Settings → Variables):
   ```
   DISCORD_TOKEN=your-bot-token
   CLIENT_ID=your-application-id
   MONGODB_URI=<paste the Mongo connection string from step 3>
   ADMIN_ROLE_IDS=roleId1,roleId2   # optional
   BRAND_LOGO_URL=https://...       # optional
   ```
   Leave `GUILD_ID` unset in production (global slash commands) — set it only for a dev/test server if you want instant command updates.

5. **Deploy the slash commands once.** Either run `npm run deploy` locally with a `.env` pointed at the same values, or open a one-off shell on the Railway service (`railway run npm run deploy`) after the variables are set.

6. **Deploy.** Railway will build and start the bot, and restart it automatically on crashes (`restartPolicyType: ON_FAILURE` in `railway.json`). Check the deploy logs for `👑 CrownX Helper online as ...` to confirm it connected.

Railway doesn't require your bot to bind a port, but `src/server.js` starts a tiny health-check HTTP server automatically whenever Railway injects a `PORT` variable, so the service shows healthy in the dashboard. It's a no-op when running locally.

## Setup (local development)

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Configure environment**
   Copy `.env.example` to `.env` and fill in:
   ```
   DISCORD_TOKEN=your-bot-token
   CLIENT_ID=your-application-id
   GUILD_ID=your-test-server-id   # optional, for instant command sync while developing
   MONGODB_URI=mongodb://127.0.0.1:27017/crownx
   ADMIN_ROLE_IDS=roleId1,roleId2  # optional, in addition to Administrator perm
   BRAND_LOGO_URL=https://...      # optional, shown as thumbnail/author icon
   ```

3. **Enable the Message Content intent**
   In the [Discord Developer Portal](https://discord.com/developers/applications) → your app → Bot, turn on **Message Content Intent** (required for the `$` prefix commands).

4. **Deploy slash commands**
   ```bash
   npm run deploy
   ```

5. **Start the bot**
   ```bash
   npm start
   ```

## Project structure

```
src/
  commands/
    member/     # /i2c, /c2i, /exchange, /calculator, /rate, /status, /limits, /fees, /history, /my-exchanges, /transaction, /help
    admin/      # /setrate, /setlimit, /pauseexchange, /resumeexchange, /exchanges, /exchange-info, /audit-log
  events/       # ready, interactionCreate, messageCreate
  buttons/      # confirm/cancel, exchange type, admin pagination
  modals/       # amount entry modal (used by /exchange)
  selectMenus/  # reserved for future dropdown features
  handlers/     # loaders + dispatchers for commands/buttons/modals/events
  embeds/       # all embed builders (black/gold theme lives in baseEmbed.js)
  models/       # Mongoose schemas: User, Transaction, Settings, AuditLog
  utils/        # calculation engine, formatting, permissions, cooldowns, transaction service
  config/       # config.js — theme colors, defaults, brand text, prefix
  index.js
  deploy-commands.js
```

## Notes

- Rates, limits, fees, and pause/resume state all live in a single `Settings` document in MongoDB and are editable live via the admin commands — no restart needed.
- `/calculator` and the real exchange commands share one function (`src/utils/calculator.js`), so a quoted amount always matches what gets created.
- To change the theme, edit `colors` and `brand` in `src/config/config.js`.
